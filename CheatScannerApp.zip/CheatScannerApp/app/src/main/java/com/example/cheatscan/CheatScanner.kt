package com.example.cheatscan

import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import java.security.MessageDigest

/**
 * Сканер следов известного чит-файла (модифицированный libil2cpp.so).
 * Ищет по содержимому, а не по имени: переименование не помогает.
 * Запускать только с явного согласия пользователя.
 */
object CheatScanner {

    private const val FULL_SHA256 = "f473badb28269d0600cebb28d7e806ea86e2f53253d278ba65a4616ba2c9e66d"
    private const val SIZE = 102881456L
    private const val CHUNK = 4096

    // Хэши 4 КБ-блоков по фиксированным смещениям (уникальные, не нулевые)
    private val SAMPLES: List<Pair<Long, String>> = listOf(
        0L to "07cb6ff6ecb4b113939aa6f007b14a14e33ab18cddafdf9dfdf80d6cf936f0ec",
        3076096L to "f0374c0b754b69753d3aa8cf4e346356b87535a536b3d40cfeac7d523fd25fa5",
        6148096L to "a4ebd17a6a7336d5dc8158928454f1126b5c422fac272ccdee7ba42fbbcd7914",
        9216000L to "09b630dad404139d0451704c2863dbc710b86f1660470797ed04540af74b5902",
        12283904L to "9d62855bbad20c17e6fc8b7c1037ae995b80ce4d3969907f63da4e6d21f50735",
        15351808L to "09259c29bebd562a9271a49a756804f20bf865f2fef91663d0c6791c375999e6",
        18419712L to "5dde6083d21f53f98f68e2d1f6df2fc469ba99fb540b837553784254051af173",
        21499904L to "47f599802133347f56ecd24cfa37690f653ac90c895b96489285368c25a31d5c",
        24567808L to "eda6f4f88084df637c58064cb60b618314165a15b71033c7fd98461f0d274270",
        27635712L to "d39e90ef3b031c185bc2db254dca447c04d37e84f275ec3300fb5d3b0b364c93",
        30703616L to "1071f69faf328d506e419d9897c5480f81607ee6cff9241c0cd1f85184982a47",
        33771520L to "fb25da713d23b7c22aff0b87118f2f6c419a708967a0730017528a0103c6060d",
        36839424L to "22acd038987fc8f5614e989232d853ba91b71c33bab324f383c52fee548f8f66",
        39907328L to "2d78bbd34c5e237d1e4b58816991667ae15e38d008581d2c3d75652cf9f90324",
        42975232L to "bdabb05fcc1933af40cea91d108ece312a9b6804519bce359d2e1665808e3b74",
        46043136L to "cc843d8de196712f0e50f895d1e551d445d81596bef7d9ec102348ba7458c8f7",
        49111040L to "03a782115c2b459116fbb3c8d88f5e677a979594014fdb8c8d50be2d2f2f06cc",
        52178944L to "d669194478a132d0c8d231d910c55f87c03971fda4e5f83a6d5b0576033cf67e",
        55246848L to "fb8c20c2c43ce24e66cfef157d2886c3599d1b3529a299fd81dde69880069e4d",
        58314752L to "6124b8ba88d85e7e3d3244ea18323fb5fd6a98858c7dd1f27954514cafa76ef7",
        61382656L to "0ea6b36bb526690940b29690d4381016bd43b98188e039db0dfda2d223315f1c",
        64450560L to "6238f963e7a273bbf6914a728f3a08ade286b0edc09b75580fb79ecfbf542223",
        67518464L to "4bd3ece140362e91ab0b67ca4cdd5800db7ad6d8bc28f32ca9b3dc00dd9b7207",
        70586368L to "0bf113a306ee27d310cae9910e29c8b93717af4557ec176f9f212850fb34c8ad",
        73654272L to "77ce8ee3f799ea3e846c6902d59f0ec8de583b065f062b32f2b71fffb3406656",
        76722176L to "6f8747e2c5f285c5661cf78c9282a8f2a7de092d1ba9dc36dffb7eab548daa4a",
        79790080L to "9d6e71c1fcc70c75c5930fd3d1b3bf7d1a205c0374b6ad3a535f8bdfa5366aa2",
        82857984L to "cc065c71660abd68d46b32a3cccd23eb9aaa5426c6a971f6455d0c98c68568a7",
        85925888L to "546c903c3f1cddefed9011f94f7199aca08f8f3164c48d100f82db112e7f4aa5",
        88993792L to "c4e63e5815ab5a104a8b6c72ac4c93bf557a742889c8bf5854b290de34dab10a",
        92061696L to "47e56c63de4f50a9586b775a79d5a3648e075f23bf335d83fe554a88ec1a3c6e",
        95129600L to "3b2306ef34898033ea404188a540303963e466afc49557c91b5937b02f4663bb"
    )

    enum class Verdict { EXACT, PARTIAL, CLEAN }
    data class Hit(val file: File, val verdict: Verdict, val score: Double)

    fun scan(roots: List<File>): List<Hit> {
        val hits = mutableListOf<Hit>()
        val seen = HashSet<String>()
        for (root in roots) {
            root.walkTopDown().onFail { _, _ -> }.filter { it.isFile }.forEach { f ->
                if (!seen.add(f.absolutePath)) return@forEach
                try {
                    if (f.length() in (SIZE * 9 / 10)..(SIZE * 11 / 10)) {
                        val hit = check(f)
                        if (hit.verdict != Verdict.CLEAN) hits += hit
                    } else if (f.extension.lowercase() in ARCHIVES && f.length() > 1_000_000) {
                        checkZip(f)?.let { hits += it }
                    }
                } catch (_: Exception) { }
            }
        }
        return hits
    }

    private val ARCHIVES = setOf("apk", "zip", "obb", "xapk", "apks")

    // Файл внутри архива (APK/ZIP/OBB): только точное совпадение
    private fun checkZip(f: File): Hit? {
        java.util.zip.ZipFile(f).use { z ->
            for (e in z.entries()) {
                if (!e.isDirectory && e.size == SIZE) {
                    val md = MessageDigest.getInstance("SHA-256")
                    z.getInputStream(e).use { s ->
                        val b = ByteArray(1 shl 16)
                        while (true) { val r = s.read(b); if (r < 0) break; md.update(b, 0, r) }
                    }
                    val h = md.digest().joinToString("") { "%02x".format(it) }
                    if (h == FULL_SHA256) return Hit(f, Verdict.EXACT, 1.0)
                }
            }
        }
        return null
    }

    private fun check(f: File): Hit {
        if (f.length() == SIZE && sha256(f) == FULL_SHA256) return Hit(f, Verdict.EXACT, 1.0)
        // Частичное совпадение: измененная копия того же чита
        var matched = 0
        RandomAccessFile(f, "r").use { raf ->
            val buf = ByteArray(CHUNK)
            for ((off, h) in SAMPLES) {
                if (off + CHUNK > raf.length()) continue
                raf.seek(off)
                raf.readFully(buf)
                if (sha256(buf) == h) matched++
            }
        }
        val score = matched.toDouble() / SAMPLES.size
        return Hit(f, if (score >= 0.5) Verdict.PARTIAL else Verdict.CLEAN, score)
    }

    /** Проверка потока (например, вывода shell через Shizuku): полный хэш + контрольные блоки. */
    fun checkStream(input: InputStream): Pair<Verdict, Double> {
        val md = MessageDigest.getInstance("SHA-256")
        val byBlock = SAMPLES.associate { (off, h) -> (off / CHUNK) to h }
        val buf = ByteArray(CHUNK)
        var block = 0L
        var total = 0L
        var matched = 0
        while (true) {
            var n = 0
            while (n < CHUNK) {
                val r = input.read(buf, n, CHUNK - n)
                if (r < 0) break
                n += r
            }
            if (n == 0) break
            md.update(buf, 0, n)
            total += n
            if (n == CHUNK) byBlock[block]?.let { if (sha256(buf) == it) matched++ }
            block++
            if (n < CHUNK) break
        }
        val full = md.digest().joinToString("") { "%02x".format(it) }
        val score = matched.toDouble() / SAMPLES.size
        return when {
            total == SIZE && full == FULL_SHA256 -> Verdict.EXACT to 1.0
            score >= 0.5 -> Verdict.PARTIAL to score
            else -> Verdict.CLEAN to score
        }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().buffered().use { s ->
            val b = ByteArray(1 shl 16)
            while (true) { val r = s.read(b); if (r < 0) break; md.update(b, 0, r) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun sha256(b: ByteArray) =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
}
