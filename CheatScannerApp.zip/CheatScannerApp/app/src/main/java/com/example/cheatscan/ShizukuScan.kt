package com.example.cheatscan

import rikka.shizuku.Shizuku
import java.io.File

/** Сканирование Android/data и Android/obb с правами shell через Shizuku. */
object ShizukuScan {
    private const val BASE = "/storage/emulated/0/Android"
    private const val MIN = 92593310L   // 90% размера эталона
    private const val MAX = 113169601L  // 110% размера эталона

    private fun run(cmd: String): Process {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        return m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    }

    private fun lines(cmd: String): List<String> {
        val p = run(cmd)
        val out = p.inputStream.bufferedReader().readLines()
        p.waitFor()
        return out.filter { it.startsWith("/") }
    }

    /** Возвращает (сколько файлов проверено, найденные совпадения). */
    fun scan(): Pair<Int, List<CheatScanner.Hit>> {
        val dirs = "$BASE/data $BASE/obb"
        val byName = lines("find $dirs -type f -name libil2cpp.so 2>/dev/null")
        val bySize = lines("find $dirs -type f -size +${MIN}c -size -${MAX}c 2>/dev/null")
        val paths = (byName + bySize).distinct()
        val hits = mutableListOf<CheatScanner.Hit>()
        for (path in paths) {
            val q = run("cat '" + path.replace("'", "'\\''") + "' 2>/dev/null")
            val (verdict, score) = q.inputStream.use { CheatScanner.checkStream(it) }
            q.destroy()
            if (verdict != CheatScanner.Verdict.CLEAN) hits += CheatScanner.Hit(File(path), verdict, score)
        }
        return paths.size to hits
    }
}
