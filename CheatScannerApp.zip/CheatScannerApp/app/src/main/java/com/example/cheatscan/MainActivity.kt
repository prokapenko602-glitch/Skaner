package com.example.cheatscan

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var btn: Button
    private lateinit var btnShizuku: Button

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        runOnUiThread {
            if (result == PackageManager.PERMISSION_GRANTED) startShizukuScan()
            else info.text = "Доступ для Shizuku не выдан."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply {
            textSize = 15f
            text = "Приложение проверит телефон на наличие известного чит-файла (libil2cpp.so). " +
                "Файлы никуда не отправляются и не изменяются. " +
                "Нажимая кнопки проверки, вы соглашаетесь на эту проверку."
        })
        btn = Button(this).apply { text = "Проверить память и приложения"; setOnClickListener { onScanClick() } }
        btnShizuku = Button(this).apply { text = "Проверить Android/data (Shizuku)"; setOnClickListener { onShizukuClick() } }
        root.addView(btn)
        root.addView(btnShizuku)
        info = TextView(this).apply { textSize = 15f; setTextIsSelectable(true) }
        root.addView(ScrollView(this).apply { addView(info) })
        setContentView(root)
        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (_: Throwable) { }
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun render(prefix: String, hits: List<CheatScanner.Hit>): String =
        if (hits.isEmpty()) "$prefix\nСледов чита не найдено."
        else "$prefix\nНАЙДЕНО (${hits.size}):\n\n" + hits.joinToString("\n\n") {
            "${it.file.absolutePath}\n" +
                if (it.verdict == CheatScanner.Verdict.EXACT) "точная копия"
                else "похожий файл, ${(it.score * 100).toInt()}%"
        }

    // ---------- Обычная проверка ----------
    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun onScanClick() {
        if (!hasAccess()) {
            info.text = "Выдайте доступ к файлам, затем вернитесь и нажмите кнопку ещё раз."
            if (Build.VERSION.SDK_INT >= 30) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1)
            }
            return
        }
        btn.isEnabled = false
        info.text = "Идёт проверка, это может занять несколько минут…"
        Thread {
            val roots = mutableListOf<File>(Environment.getExternalStorageDirectory())
            for (a in packageManager.getInstalledApplications(0)) {
                File(a.sourceDir).parentFile?.let { roots += it }
            }
            val text = try { render("", CheatScanner.scan(roots)) } catch (e: Exception) { "Ошибка: ${e.message}" }
            runOnUiThread { btn.isEnabled = true; info.text = text.trim() }
        }.start()
    }

    // ---------- Проверка Android/data через Shizuku ----------
    private fun onShizukuClick() {
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!running) {
            info.text = "Shizuku не запущен. Откройте Shizuku, запустите его (через «Беспроводную отладку») и вернитесь сюда."
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            return
        }
        val granted = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        if (!granted) {
            Shizuku.requestPermission(100)
            return
        }
        startShizukuScan()
    }

    private fun startShizukuScan() {
        btnShizuku.isEnabled = false
        info.text = "Проверка Android/data и Android/obb…"
        Thread {
            val text = try {
                val (checked, hits) = ShizukuScan.scan()
                render("Проверено файлов: $checked", hits)
            } catch (e: Throwable) {
                "Ошибка Shizuku: ${e.javaClass.simpleName}: ${e.message}"
            }
            runOnUiThread { btnShizuku.isEnabled = true; info.text = text }
        }.start()
    }
}
