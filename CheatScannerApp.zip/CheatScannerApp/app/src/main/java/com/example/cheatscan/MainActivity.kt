package com.example.cheatscan

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        root.addView(TextView(this).apply {
            textSize = 15f
            text = "Приложение проверит память телефона и установленные приложения на наличие " +
                "известного чит-файла (libil2cpp.so). Файлы никуда не отправляются и не изменяются. " +
                "Нажимая «Проверить», вы соглашаетесь на эту проверку."
        })
        btn = Button(this).apply { text = "Проверить"; setOnClickListener { onScanClick() } }
        root.addView(btn)
        info = TextView(this).apply { textSize = 15f; setTextIsSelectable(true) }
        root.addView(ScrollView(this).apply { addView(info) })
        setContentView(root)
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun onScanClick() {
        if (!hasAccess()) {
            info.text = "Выдайте доступ к файлам, затем вернитесь и нажмите «Проверить» ещё раз."
            if (Build.VERSION.SDK_INT >= 30) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 1)
            }
            return
        }
        btn.isEnabled = false
        info.text = "Идёт проверка, это может занять несколько минут…"
        Thread {
            val roots = mutableListOf<File>(Environment.getExternalStorageDirectory())
            for (a in packageManager.getInstalledApplications(0)) {
                File(a.sourceDir).parentFile?.let { roots += it }
            }
            val hits = try { CheatScanner.scan(roots) } catch (e: Exception) { emptyList() }
            runOnUiThread {
                btn.isEnabled = true
                info.text = if (hits.isEmpty()) "Следов чита не найдено."
                else "НАЙДЕНО (${hits.size}):\n\n" + hits.joinToString("\n\n") {
                    "${it.file.absolutePath}\n${if (it.verdict == CheatScanner.Verdict.EXACT) "точная копия" else "похожий файл, ${(it.score * 100).toInt()}%"}"
                }
            }
        }.start()
    }
}
